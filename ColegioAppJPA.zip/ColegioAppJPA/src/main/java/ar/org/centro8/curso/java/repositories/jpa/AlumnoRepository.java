package ar.org.centro8.curso.java.repositories.jpa;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
public class AlumnoRepository implements I_AlumnoRepository{

    private EntityManagerFactory emf;

    public AlumnoRepository(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    @Override
    public void save(Alumno alumno) {
        if(alumno==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(alumno);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void remove(Alumno alumno) {
        if(alumno==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(alumno));
        em.getTransaction().commit();
        em.close();    
    }

    @Override
    public void update(Alumno alumno) {
        if(alumno==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(em.merge(alumno));
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public List<Alumno> getAll() {
        List<Alumno> list=new ArrayList();
        EntityManager em=emf.createEntityManager();
        list=(List<Alumno>)em.createNamedQuery("Alumno.findAll").getResultList();
        em.close();
        return list;
    }
    
}